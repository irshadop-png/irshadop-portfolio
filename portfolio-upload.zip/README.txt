IRSHAD OP — PORTFOLIO WEBSITE PACKAGE

Upload this ZIP to your GitHub repository as portfolio-upload.zip. The included GitHub Actions workflow extracts it and deploys the site to GitHub Pages.

Contains: responsive index.html, 134 portfolio images (WebP, quality 82, original pixel dimensions retained), and H.264 MP4 intro/background videos for broad mobile browser compatibility.

Extracting the ZIP in the deployment workflow places index.html and media/ at the site root.
